"""Transcribe one WAV file and save timestamps in its own run folder."""

import argparse
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_AUDIO = BASE_DIR / "audio_sources" / "audio.wav"


def resolve_input(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else BASE_DIR / path


def main() -> None:
    parser = argparse.ArgumentParser(description="Transcribe a WAV file with Faster-Whisper.")
    parser.add_argument("--audio", default=str(DEFAULT_AUDIO), help="WAV file to process")
    parser.add_argument("--model", default="small", help="Faster-Whisper model name")
    parser.add_argument("--overwrite", action="store_true", help="Replace existing timestamps")
    args = parser.parse_args()

    audio_file = resolve_input(args.audio)
    if not audio_file.is_file():
        parser.error(f"Audio file not found: {audio_file}")
    if audio_file.suffix.lower() != ".wav":
        parser.error(f"Expected a WAV file: {audio_file}")

    timestamps_file = BASE_DIR / "timestamps.tsv"
    if timestamps_file.exists() and not args.overwrite:
        parser.error(f"Timestamps already exist: {timestamps_file} (use --overwrite to replace)")
    timestamps_file.parent.mkdir(parents=True, exist_ok=True)

    try:
        from faster_whisper import WhisperModel
    except ImportError as error:
        raise SystemExit("Faster-Whisper is not installed in this Python environment.") from error

    model = WhisperModel(args.model)
    segments, _ = model.transcribe(str(audio_file), language="ko")
    with timestamps_file.open("w", encoding="utf-8", newline="") as output:
        output.write("start\tend\ttext\n")
        for segment in segments:
            text = segment.text.strip().replace("\t", " ").replace("\n", " ")
            output.write(f"{segment.start:.3f}\t{segment.end:.3f}\t{text}\n")

    print(f"Timestamps saved: {timestamps_file}")


if __name__ == "__main__":
    main()
