"""Cut one WAV file using its timestamps; keep each timestamp/speaker result separate."""

import argparse
import csv
import re
import wave
from datetime import datetime, time
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_AUDIO = BASE_DIR / "audio_sources" / "audio.wav"


def resolve_input(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else BASE_DIR / path


def to_seconds(value: str) -> float:
    if value is None or str(value).strip() == "":
        raise ValueError("empty timestamp")
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, datetime):
        value = value.time()
    if isinstance(value, time):
        return value.hour * 3600 + value.minute * 60 + value.second + value.microsecond / 1_000_000
    parts = str(value).strip().split(":")
    if len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    return float(str(value).strip())


def safe_name(value: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "_", value).strip(" .")


def read_timestamps(path: Path, sheet_name: str | None) -> tuple[list[str], list[list]]:
    if path.suffix.lower() == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as error:
            raise SystemExit("To read .xlsx timestamps, install openpyxl in this Python environment.") from error
        workbook = load_workbook(path, read_only=True, data_only=True)
        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                raise ValueError(f"Sheet '{sheet_name}' not found. Available: {', '.join(workbook.sheetnames)}")
        else:
            sheet_name = next(
                (name for name in ("MFA_Cuts", "Segments", "Transcript_Timed") if name in workbook.sheetnames),
                None,
            )
            if sheet_name is None:
                raise ValueError(f"No timestamp sheet found in {path.name}: {', '.join(workbook.sheetnames)}")
        iterator = workbook[sheet_name].iter_rows(values_only=True)
        headers = [str(item or "").strip().casefold() for item in next(iterator)]
        rows = [list(row) for row in iterator]
        workbook.close()
        return headers, rows

    if path.suffix.lower() not in (".tsv", ".csv"):
        raise ValueError("Timestamp file must be .xlsx, .tsv, or .csv")
    with path.open("r", encoding="utf-8-sig", newline="") as source:
        sample = source.read(4096)
        source.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters="\t,;")
        except csv.Error:
            dialect = csv.excel_tab if path.suffix.lower() == ".tsv" else csv.excel
        reader = csv.reader(source, dialect)
        headers = [item.strip().casefold() for item in next(reader)]
        return headers, list(reader)


def main() -> None:
    parser = argparse.ArgumentParser(description="Cut a WAV file using an XLSX/TSV/CSV timestamp file.")
    parser.add_argument("--audio", default=str(DEFAULT_AUDIO), help="WAV file to cut")
    parser.add_argument("--timestamps", help="Edited XLSX/TSV/CSV file; defaults to the matching run folder")
    parser.add_argument("--sheet", help="Excel sheet name; defaults to MFA_Cuts, Segments, or Transcript_Timed")
    parser.add_argument("--speaker", help="Keep only this Speaker or Speaker_ASCII value")
    parser.add_argument("--overwrite", action="store_true", help="Replace existing segment files")
    args = parser.parse_args()

    audio_file = resolve_input(args.audio)
    if not audio_file.is_file():
        parser.error(f"Audio file not found: {audio_file}")
    timestamps_file = resolve_input(args.timestamps) if args.timestamps else BASE_DIR / "timestamps.tsv"
    if not timestamps_file.is_file():
        parser.error(f"Timestamps not found: {timestamps_file}")

    try:
        headers, rows = read_timestamps(timestamps_file, args.sheet)
    except (ValueError, StopIteration) as error:
        parser.error(str(error))

    indices = {name: index for index, name in enumerate(headers)}
    if "start" not in indices or "end" not in indices:
        parser.error("Timestamps must contain start and end columns")
    speaker_index = next((indices[name] for name in ("speaker_ascii", "speaker") if name in indices), None)
    if args.speaker and speaker_index is None:
        parser.error("--speaker requires a Speaker or Speaker_ASCII column")
    text_index = next((indices[name] for name in ("text", "transcript", "notes", "내용") if name in indices), None)
    if text_index is None:
        parser.error("Timestamps must contain a Text or Transcript column for .lab files")

    def value(row: list, column: int | None):
        return row[column] if column is not None and column < len(row) else ""

    if speaker_index is not None:
        speakers = sorted({str(value(row, speaker_index)).strip() for row in rows if value(row, speaker_index)})
        if len(speakers) > 1 and not args.speaker:
            parser.error(f"Multiple speakers in {timestamps_file.name}; choose --speaker: {', '.join(speakers)}")
        if args.speaker and args.speaker.casefold() not in {name.casefold() for name in speakers}:
            parser.error(f"Speaker '{args.speaker}' not found. Available: {', '.join(speakers)}")

    output_dir = BASE_DIR / "segments"
    if args.speaker:
        output_dir = output_dir / safe_name(args.speaker)
    if output_dir.exists() and any(output_dir.iterdir()) and not args.overwrite:
        parser.error(f"Output folder is not empty: {output_dir} (use --overwrite to replace)")
    output_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    with wave.open(str(audio_file), "rb") as audio:
        params = audio.getparams()
        frame_rate = audio.getframerate()
        frame_count = audio.getnframes()
        for row_number, row in enumerate(rows, start=2):
            if not row or not any(item.strip() for item in row):
                continue
            speaker = str(value(row, speaker_index) or "").strip()
            if args.speaker and speaker.casefold() != args.speaker.casefold():
                continue
            try:
                start = to_seconds(value(row, indices["start"]))
                end = to_seconds(value(row, indices["end"]))
            except (TypeError, ValueError) as error:
                print(f"Skipping row {row_number}: invalid timestamp ({error})")
                continue
            start_frame = max(0, round(start * frame_rate))
            end_frame = min(frame_count, round(end * frame_rate))
            if end <= start or end_frame <= start_frame or start_frame >= frame_count:
                print(f"Skipping row {row_number}: invalid or out-of-range interval")
                continue
            count += 1
            stem = f"{count:04d}"
            if speaker and not args.speaker:
                stem += f"_{safe_name(speaker)}"
            transcript = str(value(row, text_index) or "").strip()
            audio.setpos(start_frame)
            frames = audio.readframes(end_frame - start_frame)
            with wave.open(str(output_dir / f"{stem}.wav"), "wb") as segment:
                segment.setparams(params)
                segment.writeframes(frames)
            (output_dir / f"{stem}.lab").write_text(transcript, encoding="utf-8")

    print(f"Created {count} WAV/LAB pairs in: {output_dir}")


if __name__ == "__main__":
    main()
