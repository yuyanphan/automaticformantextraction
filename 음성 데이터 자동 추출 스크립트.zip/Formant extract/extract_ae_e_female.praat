############################################################
# VERIFIED BATCH EXTRACTION FOR KOREAN /AE/ AND /E/
# FEMALE SPEAKER VERSION
#
# Works on ALL currently selected Sound + TextGrid objects.
# Pairing is by identical Praat object name.
#
# Verified from user's MFA diagnostic:
#   E group  : e, eː
#   AE group : ɛ, ɛː
#
# Output labels use ASCII "AE" and "E" to avoid display/font
# problems in Praat Info/Table windows.
#
# Measurement:
#   F1, F2 at 50% of each target phone interval
############################################################

phoneTier = 2
timeStep = 0.005
numberOfFormants = 5
maximumFormant = 5500
windowLength = 0.025
preEmphasis = 50
minimumDuration = 0.050

# ----------------------------------------------------------
# GET ALL SELECTED OBJECTS
# ----------------------------------------------------------

soundIDs# = selected#("Sound")
textgridIDs# = selected#("TextGrid")

nSounds = size(soundIDs#)
nTextGrids = size(textgridIDs#)

if nSounds = 0
    exitScript: "No Sound objects selected. Select all objects first."
endif

if nTextGrids = 0
    exitScript: "No TextGrid objects selected. Select all objects first."
endif

# ----------------------------------------------------------
# RESULT TABLES
# ----------------------------------------------------------

tokenTable = Create Table with column names:
... "ae_e_tokens_batch_female",
... 0,
... "Speaker File Token_ID File_token_ID Interval_number Vowel_group MFA_phone Start_s End_s Duration_s Midpoint_s F1_Hz F2_Hz Status"

summaryTable = Create Table with column names:
... "ae_e_summary_batch_female",
... 0,
... "Level Speaker File Vowel_group N_total N_OK N_SHORT N_UNDEFINED Mean_F1_Hz Mean_F2_Hz"

# ----------------------------------------------------------
# CORPUS ACCUMULATORS
# ----------------------------------------------------------

globalTokenID = 0
processedPairs = 0
unmatchedSounds = 0

corpusTotalAE = 0
corpusOKAE = 0
corpusShortAE = 0
corpusUndefinedAE = 0
corpusSumF1AE = 0
corpusSumF2AE = 0

corpusTotalE = 0
corpusOKE = 0
corpusShortE = 0
corpusUndefinedE = 0
corpusSumF1E = 0
corpusSumF2E = 0

# ==========================================================
# LOOP THROUGH ALL SELECTED SOUNDS
# ==========================================================

for si from 1 to nSounds

    sound = soundIDs#[si]
    selectObject: sound
    soundName$ = selected$("Sound")

    # Find matching TextGrid by exact object name
    textgrid = 0

    for ti from 1 to nTextGrids
        candidate = textgridIDs#[ti]
        selectObject: candidate
        tgName$ = selected$("TextGrid")

        if tgName$ = soundName$
            textgrid = candidate
            ti = nTextGrids
        endif
    endfor

    if textgrid = 0
        unmatchedSounds = unmatchedSounds + 1
        appendInfoLine: "NO MATCH: Sound ", soundName$

    else
        processedPairs = processedPairs + 1

        underscore = index(soundName$, "_")
        if underscore > 1
            speaker$ = left$(soundName$, underscore - 1)
        else
            speaker$ = soundName$
        endif

        selectObject: textgrid
        nTiers = Get number of tiers

        if nTiers < phoneTier
            appendInfoLine: "NO PHONE TIER 2: ", soundName$

        else
            # Create temporary Formant object
            selectObject: sound
            formant = To Formant (burg):
            ... timeStep,
            ... numberOfFormants,
            ... maximumFormant,
            ... windowLength,
            ... preEmphasis

            # File-level accumulators
            fileTokenID = 0

            totalAE = 0
            okAE = 0
            shortAE = 0
            undefAE = 0
            sumF1AE = 0
            sumF2AE = 0

            totalE = 0
            okE = 0
            shortE = 0
            undefE = 0
            sumF1E = 0
            sumF2E = 0

            selectObject: textgrid
            nIntervals = Get number of intervals: phoneTier

            for ii from 1 to nIntervals

                selectObject: textgrid
                phone$ = Get label of interval: phoneTier, ii

                isTarget = 0
                isAE = 0
                vowelGroup$ = ""

                if phone$ = "ɛ" or phone$ = "ɛː"
                    isTarget = 1
                    isAE = 1
                    vowelGroup$ = "AE"

                elsif phone$ = "e" or phone$ = "eː"
                    isTarget = 1
                    vowelGroup$ = "E"
                endif

                if isTarget = 1

                    globalTokenID = globalTokenID + 1
                    fileTokenID = fileTokenID + 1

                    startTime = Get starting point: phoneTier, ii
                    endTime = Get end point: phoneTier, ii
                    duration = endTime - startTime
                    midpoint = startTime + duration / 2

                    selectObject: formant
                    f1 = Get value at time: 1, midpoint, "Hertz", "Linear"
                    f2 = Get value at time: 2, midpoint, "Hertz", "Linear"

                    status$ = "OK"

                    if duration < minimumDuration
                        status$ = "SHORT"
                    endif

                    if f1 = undefined or f2 = undefined
                        if status$ = "SHORT"
                            status$ = "SHORT_UNDEFINED"
                        else
                            status$ = "UNDEFINED"
                        endif
                    endif

                    # Update counters
                    if isAE = 1
                        totalAE = totalAE + 1
                        corpusTotalAE = corpusTotalAE + 1

                        if status$ = "OK"
                            okAE = okAE + 1
                            corpusOKAE = corpusOKAE + 1
                            sumF1AE = sumF1AE + f1
                            sumF2AE = sumF2AE + f2
                            corpusSumF1AE = corpusSumF1AE + f1
                            corpusSumF2AE = corpusSumF2AE + f2
                        elsif status$ = "SHORT"
                            shortAE = shortAE + 1
                            corpusShortAE = corpusShortAE + 1
                        else
                            undefAE = undefAE + 1
                            corpusUndefinedAE = corpusUndefinedAE + 1
                        endif

                    else
                        totalE = totalE + 1
                        corpusTotalE = corpusTotalE + 1

                        if status$ = "OK"
                            okE = okE + 1
                            corpusOKE = corpusOKE + 1
                            sumF1E = sumF1E + f1
                            sumF2E = sumF2E + f2
                            corpusSumF1E = corpusSumF1E + f1
                            corpusSumF2E = corpusSumF2E + f2
                        elsif status$ = "SHORT"
                            shortE = shortE + 1
                            corpusShortE = corpusShortE + 1
                        else
                            undefE = undefE + 1
                            corpusUndefinedE = corpusUndefinedE + 1
                        endif
                    endif

                    # Store one row per target token
                    selectObject: tokenTable
                    Append row
                    row = Get number of rows

                    Set string value: row, "Speaker", speaker$
                    Set string value: row, "File", soundName$
                    Set numeric value: row, "Token_ID", globalTokenID
                    Set numeric value: row, "File_token_ID", fileTokenID
                    Set numeric value: row, "Interval_number", ii
                    Set string value: row, "Vowel_group", vowelGroup$
                    Set string value: row, "MFA_phone", phone$
                    Set numeric value: row, "Start_s", startTime
                    Set numeric value: row, "End_s", endTime
                    Set numeric value: row, "Duration_s", duration
                    Set numeric value: row, "Midpoint_s", midpoint
                    Set numeric value: row, "F1_Hz", f1
                    Set numeric value: row, "F2_Hz", f2
                    Set string value: row, "Status", status$

                endif

            endfor

            # File summary AE
            selectObject: summaryTable
            Append row
            row = Get number of rows
            Set string value: row, "Level", "FILE"
            Set string value: row, "Speaker", speaker$
            Set string value: row, "File", soundName$
            Set string value: row, "Vowel_group", "AE"
            Set numeric value: row, "N_total", totalAE
            Set numeric value: row, "N_OK", okAE
            Set numeric value: row, "N_SHORT", shortAE
            Set numeric value: row, "N_UNDEFINED", undefAE
            if okAE > 0
                Set numeric value: row, "Mean_F1_Hz", sumF1AE / okAE
                Set numeric value: row, "Mean_F2_Hz", sumF2AE / okAE
            endif

            # File summary E
            Append row
            row = Get number of rows
            Set string value: row, "Level", "FILE"
            Set string value: row, "Speaker", speaker$
            Set string value: row, "File", soundName$
            Set string value: row, "Vowel_group", "E"
            Set numeric value: row, "N_total", totalE
            Set numeric value: row, "N_OK", okE
            Set numeric value: row, "N_SHORT", shortE
            Set numeric value: row, "N_UNDEFINED", undefE
            if okE > 0
                Set numeric value: row, "Mean_F1_Hz", sumF1E / okE
                Set numeric value: row, "Mean_F2_Hz", sumF2E / okE
            endif

            removeObject: formant

        endif
    endif
endfor

# ----------------------------------------------------------
# CORPUS SUMMARY
# ----------------------------------------------------------

selectObject: summaryTable

Append row
row = Get number of rows
Set string value: row, "Level", "CORPUS"
Set string value: row, "Speaker", "ALL"
Set string value: row, "File", "ALL"
Set string value: row, "Vowel_group", "AE"
Set numeric value: row, "N_total", corpusTotalAE
Set numeric value: row, "N_OK", corpusOKAE
Set numeric value: row, "N_SHORT", corpusShortAE
Set numeric value: row, "N_UNDEFINED", corpusUndefinedAE
if corpusOKAE > 0
    Set numeric value: row, "Mean_F1_Hz", corpusSumF1AE / corpusOKAE
    Set numeric value: row, "Mean_F2_Hz", corpusSumF2AE / corpusOKAE
endif

Append row
row = Get number of rows
Set string value: row, "Level", "CORPUS"
Set string value: row, "Speaker", "ALL"
Set string value: row, "File", "ALL"
Set string value: row, "Vowel_group", "E"
Set numeric value: row, "N_total", corpusTotalE
Set numeric value: row, "N_OK", corpusOKE
Set numeric value: row, "N_SHORT", corpusShortE
Set numeric value: row, "N_UNDEFINED", corpusUndefinedE
if corpusOKE > 0
    Set numeric value: row, "Mean_F1_Hz", corpusSumF1E / corpusOKE
    Set numeric value: row, "Mean_F2_Hz", corpusSumF2E / corpusOKE
endif

# ----------------------------------------------------------
# FINAL REPORT
# ----------------------------------------------------------

# ----------------------------------------------------------
# AUTOMATIC CSV OUTPUT
# ----------------------------------------------------------

tokenOutput$ = "ae_e_tokens_batch_female.csv"
summaryOutput$ = "ae_e_summary_batch_female.csv"

selectObject: tokenTable
Save as comma-separated file: tokenOutput$
selectObject: summaryTable
Save as comma-separated file: summaryOutput$

selectObject: tokenTable
plusObject: summaryTable

writeInfoLine: "=== VERIFIED BATCH EXTRACTION COMPLETED ==="
appendInfoLine: "Speaker setting: FEMALE"
appendInfoLine: "Maximum formant: ", maximumFormant, " Hz"
appendInfoLine: "Selected Sounds: ", nSounds
appendInfoLine: "Selected TextGrids: ", nTextGrids
appendInfoLine: "Processed matched pairs: ", processedPairs
appendInfoLine: "Unmatched Sounds: ", unmatchedSounds
appendInfoLine: ""
appendInfoLine: "AE group (epsilon / epsilon-long): ", corpusTotalAE
appendInfoLine: "E group (e / e-long): ", corpusTotalE
appendInfoLine: "Total target tokens: ", globalTokenID
appendInfoLine: ""
appendInfoLine: "Tables created:"
appendInfoLine: "ae_e_tokens_batch_female"
appendInfoLine: "ae_e_summary_batch_female"
appendInfoLine: "CSV files saved:"
appendInfoLine: tokenOutput$
appendInfoLine: summaryOutput$
